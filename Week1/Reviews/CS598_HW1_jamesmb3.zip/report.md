---
puppeteer:
    landscape: false
    format: "A4"
    printBackground: true
    preferCSSPageSize: true
    margin:
        left: 0
        bottom: 0


---
# CS 598: Foundations of Data Curation
### Assignment 1: Relational Schema Design Exercise

**Author**: jamesmb3@illinois.edu

**Date**: 09/07/2019

***





# Report Tools Used

To reproduce this report in its entirety, the following tools must be installed.

- **Atom** - A hackable text editor for the 21st Century [download](https://atom.io/) - used [Markdown Preview Enhanced](https://shd101wyy.github.io/markdown-preview-enhanced/#/) package for markdown and prince for pdf conversion.
- **MySQL Workbench** - MySQL Workbench provides data modeling, SQL development, and comprehensive administration tools for server configuration, user administration, backup, and much more.
[download](https://dev.mysql.com/downloads/workbench/)


# Overview

*1. Task: Write a short narrative description of each file we have given you. What information do they contain? How is the information formatted and organized? What kinds of information is shared among the files?*

This exercise is prompting to examine a fictitious auto dealer with three (3) departments that utilize different data formats for storing data.  Our task is to unify the data into one format by examining the data structure and proposing a normalized relational schema in order to serve the client better.  We start by examining each of the three (3) files individually:


#1. Source Dataset

- **FileA.txt**  - Text file (txt) that contains information about **Inventory** of individual cars - it appears this would be some unique information such as Vehicle Identification Number (VIN) and additional characteristic information such as make, model and color as well as MSRP.  Specific fields are not given - there are assumptions made about the column names.
	* `Inventory:id` primary key


- **FileB.csv**  - Comma separated value (csv) file that contains **Customer Sales** data, including PurchasePrice, Customer LastName, and Customer FirstName.  Each line within the text file represents and individual sales transaction.  There is no description of each column - so assumptions are made.
	* `Sales:id` primary key


- **FileC.txt**  - Word document (docx) file that contains **Customer Relations** information. It contains customer information and notes.  There is an empty line separator between customer records. Specific fields are not listed - assumptions are made about the layout and format.
	* no identifiable primary key within source - surrogate must be created


We observe that vehicle information is within FileA, customer information in FileB and the linkage of customers **buying** cars in within FileB.


#2. Destination - Schema


### Visual
![diagram](er-diagram-model1.png)


### DDL


```sql


-- -----------------------------------------------------
-- Table `dealership`.`vehicle`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`vehicle` (
  `id` INT NOT NULL,
  `vin` VARCHAR(45) NULL,
  `make` VARCHAR(45) NULL,
  `model` VARCHAR(45) NULL,
  `year` INT NULL,
  `color` VARCHAR(45) NULL,
  `engine` VARCHAR(45) NULL,
  `transmission` VARCHAR(45) NULL,
  `body` VARCHAR(45) NULL,
  `msrp` DOUBLE NULL,
  PRIMARY KEY (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`inventory`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`inventory` (
  `id` INT NOT NULL,
  `vehicle_id` INT NOT NULL,
  `date_added` TIMESTAMP NULL,
  `date_removed` TIMESTAMP NULL,
  `note` TEXT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_inventory_vehicle1_idx` (`vehicle_id` ASC) VISIBLE,
  CONSTRAINT `fk_inventory_vehicle1`
    FOREIGN KEY (`vehicle_id`)
    REFERENCES `dealership`.`vehicle` (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`occupation`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`occupation` (
  `id` INT NOT NULL,
  `occupation_name` VARCHAR(100) NULL,
  PRIMARY KEY (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`customer` (
  `id` INT NOT NULL,
  `firstname` VARCHAR(100) NULL,
  `lastname` VARCHAR(100) NULL,
  `mi` VARCHAR(45) NULL,
  `repeatcustomer` TINYINT NULL,
  `occupation_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_customer_occupation1_idx` (`occupation_id` ASC) VISIBLE,
  CONSTRAINT `fk_customer_occupation1`
    FOREIGN KEY (`occupation_id`)
    REFERENCES `dealership`.`occupation` (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`address` (
  `id` INT NOT NULL,
  `address` VARCHAR(45) NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `zip` VARCHAR(45) NULL,
  `country` VARCHAR(45) NULL,
  PRIMARY KEY (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`customer_contact`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`customer_contact` (
  `id` INT NOT NULL,
  `customer_id` INT NOT NULL,
  `address_id` INT NOT NULL,
  `date_added` TIMESTAMP NULL,
  `primary_contact` TINYINT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_customer_contact_customer1_idx` (`customer_id` ASC) VISIBLE,
  INDEX `fk_customer_contact_contact1_idx` (`address_id` ASC) VISIBLE,
  CONSTRAINT `fk_customer_contact_customer1`
    FOREIGN KEY (`customer_id`)
    REFERENCES `dealership`.`customer` (`id`),
  CONSTRAINT `fk_customer_contact_contact1`
    FOREIGN KEY (`address_id`)
    REFERENCES `dealership`.`address` (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`customer_note`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`customer_note` (
  `id` INT NOT NULL,
  `customer_id` INT NOT NULL,
  `note` TEXT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_customer_note_customer1_idx` (`customer_id` ASC) VISIBLE,
  CONSTRAINT `fk_customer_note_customer1`
    FOREIGN KEY (`customer_id`)
    REFERENCES `dealership`.`customer` (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`vehicle_sale`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`vehicle_sale` (
  `id` INT NOT NULL,
  `customer_id` INT NOT NULL,
  `inventory_id` INT NOT NULL,
  `saledate` TIMESTAMP NULL,
  `discount` DOUBLE NULL,
  `purchase_price` DOUBLE NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_sales_customer1_idx` (`customer_id` ASC) VISIBLE,
  INDEX `fk_sales_inventory1_idx` (`inventory_id` ASC) VISIBLE,
  CONSTRAINT `fk_sales_customer1`
    FOREIGN KEY (`customer_id`)
    REFERENCES `dealership`.`customer` (`id`),
  CONSTRAINT `fk_sales_inventory1`
    FOREIGN KEY (`inventory_id`)
    REFERENCES `dealership`.`inventory` (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`trade_in`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`trade_in` (
  `id` INT NOT NULL,
  `vehicle_id` INT NOT NULL,
  `trade_in_value` DOUBLE NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_trade_in_vehicle1_idx` (`vehicle_id` ASC) VISIBLE,
  CONSTRAINT `fk_trade_in_vehicle1`
    FOREIGN KEY (`vehicle_id`)
    REFERENCES `dealership`.`vehicle` (`id`))
;


-- -----------------------------------------------------
-- Table `dealership`.`trade_in_sale`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dealership`.`trade_in_sale` (
  `vehicle_sale_id` INT NOT NULL,
  `trade_in_id` INT NOT NULL,
  `trade_date` TIMESTAMP NULL,
  INDEX `fk_trade_in_sale_vehicle_sale1_idx` (`vehicle_sale_id` ASC) VISIBLE,
  INDEX `fk_trade_in_sale_trade_in1_idx` (`trade_in_id` ASC) VISIBLE,
  CONSTRAINT `fk_trade_in_sale_vehicle_sale1`
    FOREIGN KEY (`vehicle_sale_id`)
    REFERENCES `dealership`.`vehicle_sale` (`id`),
  CONSTRAINT `fk_trade_in_sale_trade_in1`
    FOREIGN KEY (`trade_in_id`)
    REFERENCES `dealership`.`trade_in` (`id`)

    )
;
```


# 3. Destination Database - Sample Data


##### vehicle
| id | vin                | make   | model   | year | color | engine    | transmission | body   | msrp   |
|----|--------------------|--------|---------|------|-------|-----------|--------------|--------|--------|
| 1  | S7enznmKTrKsbm4ceC | Tesla  | Model S | 2019 | blue  | electric  | AWD          | 4 door | 133000 |
| 2  | 98123123123        | Toyota | Camry   | 2004 | grey  | 6 cyl gas | FWD          | 4 door |        |
| 3  | 98123123124        | Toyota | Camry   | 2005 | red   | 6 cyl gas | FWD          | 4 door |        |



##### trade_in									
| id | vehicle_id | trade_in_value |
|----|------------|----------------|
| 3  | 2          | 6300           |
| 4  | 3          | 6300           |


##### trade_in_sale									
| id | trade_in_id | trade_date   |
|----|-------------|--------------|
| 10 | 3           | 9/8/19 13:32 |
| 11 | 4           | 9/8/19 13:32 |


##### inventory									
| id  | vehicle_id | date_added    | date_removed | note                          |
|-----|------------|---------------|--------------|-------------------------------|
| 100 | 1          | 5/31/19 13:32 |              | sold                          |
| 101 | 2          | 8/19/19 13:32 |              | trade-in on lot               |
| 102 | 3          | 8/29/19 13:32 |              | 2nd trade-in for tesla on lot |



##### vehicle_sale									
| id   | customer_id | inventory_id | saledate     | discount | purchase_price |
|------|-------------|--------------|--------------|----------|----------------|
| 1000 | 1000        | 100          | 9/8/19 13:32 |          | 126,700        |


##### customer									
| id   | firstname | lastname | mi | repeatcustomer | occupation_Id |
|------|-----------|----------|----|----------------|---------------|
| 1000 | Harry     | Potter   | D  |                | 30            |


##### occupation									
| id | occupation |
|----|------------|
| 30 | professor  |
| 10 | lawyer     |
| 20 | doctor     |


##### address									
| id   | address          | city    | state | zip   | country |
|------|------------------|---------|-------|-------|---------|
| 1010 | 2008 Williams Dr | Chicago | IL    | 60007 | USA     |


##### customer_contact									
| id | customer_id | address_id | date_added   | primary_contact |
|----|-------------|------------|--------------|-----------------|
| 1  | 1000        | 1010       | 9/8/19 13:34 | Y               |




# 4. Process
##### How did you decide to represent the data in the way that you did?

We start by breaking up the information into the smallest parts that conceptually belong together (sales, inventory, customers...) these larger items become tables and have an initial surrogate autogenerated primary keys.  We then can start adding attributes where necessary - and if we need to break up information we create additional tables.  


##### Did you leave out any information? If so, why?
There is redundant information in the tables when normalizing (eg. `customer name`), so that duplicate information was removed.  In production humans make mistakes and can mis-key fields, so we favor for all auto-generated keys.

Fields like `repeatcustomer` can be set within software, or can be calculated dynamically via SQL or a lookup view, we left it in for this example.  


##### Why did you choose certain things as attributes? As keys?

We favored in having the system generate keys, because none of the fields (perhaps VIN?) are unique enough over time to be a strong candidate for keys.  Almost everything else was left as attributes.

##### What were the hardest decisions you had to make in this design process?


- **Multiple Instances**- Our design allows for things like multiple trade-ins, but we can further the model to incorporate many more events that customers may have in the real world - for example dealership incentive discounts versus manufacture discounts.

- **Collisions** for example no two VIN numbers are unique, however there could be conflicts - after some research we see that every 30 years VIN gets replaced with old numbers so collisions may occur in the real world.  

- **Historical requirements** or how long should data be relevant for - should we maintain historical data for all customers/sales/inventory for the dealer?  For example we may have to keep track of warranty information for all cars sold, but not used cars.  Additional business rules for these situations would need to be applied on the data.  

- **Process** or rather the dealership process and `workflow` we would require more elaborate information on, for example, when a customer purchases a car, it is sold at the moment, but technically still in the inventory, what are the steps to finalize the transaction, and are there additional regulatory actions that need to take place (state stickers/insurance/license plates..), is there the appropriate control mechanisms for sign off, so that customers are not producing liability for the dealership.  Or another example is when they take a trade-in, does that become part of their inventory, what are the steps to put that traded-in car into the inventory (mechanical inspection, car wash...).  




##### How does your schema design support data independence?

- **Physical Data Independence** `Type1` - if the storage method changes our database should remain the same.  Storage methods can be changed without impacting existing applications.

- **Logical Data Independence** `Type2` - if new kinds of data need to be represented, then we just add more tables and link them.  We can add new tables and it impact running applications.


##### How may your schema design support the overarching goals of data curation (revisit objectives and activities of Week 1)?

Building our model helps to organize our data more conceptually and provides us with a template that we can utilize for very clear `documentation`.  By `normalizing` our data we have reduced redundant values and inconsistencies.  By adding primary key `constraints` we have helped validation and consistency.

We are able to clearly `select` data from specific tables, `develop` additional schemas on top of our current schema to enhance our data, and `revise` our entities by adding columns that may be necessary as our car-dealership evolves.

We have started the groundwork of a schema that should support various data `analysis` and we can expand our concepts to add additional tables for `auditing` and `reporting`.


##### Which curation activities could enhance or sustain the database for future discovery and use for new purposes?

We have observed as we try to accommodate future changes and growth, our complexity in our model grows.  We had walked through several scenarios for customers changing address to multiple cars being traded in for one purchase, additional information from the dealership process would be necessary for us to elaborate the model.

We can improve our `discoverability` of columns by adding an additional table that can have descriptions of all the fields for all the tables, sort of like a metadata warehouse.  This may make it easier to produce documentation and versioned instances of our database.

I think for future purposes we can improve `transparency` by making some data and reports `shared` to all stakeholders, so that we can maintain higher degree of data awareness and hopefully we can have less human error.




##### What additional activities would you recommend?

- The `collection` aspect of having the data in 3 formats would have to be revised, in this process we are converting 3 different file format, ideally the dealership would migrate its processes to use a database directly.


- Ideally we would have a staging database where we can load and pre-process the data by batches prior to loading into the schema.   This way we can ensure `integrity` prior to data being put into our production environment.

- Data from `collection` for docx is not well formatted, fields are not specified and many assumptions can be made.  In an actual production environment we would encourage that department to switch its underlying processes and `store` data differently.

- Versioning information and documenting  processes for `provenance` is critical, this is something that we would also want to document.

- Conceptually, we can also add additional meta data, such as describing user -id  and dates of row actions to all the tables like `date-created` `date-modified` `date-deleted`  `userid-created` `userid-modified` `userid-deleted` so that we have `preservation` and `reproducibility` of information for each row of data.  Wrapping all rows with this information is a simple log that allows us to see who/what user modified which row on which date.

- Statistics on the data can be very helpful for `auditing` and fraud detection.  
We have noticed that a person buying a \$133,000 Tesla car is trading in a \$6300.00 car of unknown type, which may create a fraud alert or at least alert senior management.

- We would also find ways to ensure appropriate data access for `security` so that for example sales associates may not need access to personal credit information.


# Acknowledgements
This report acknowledges [Prof. Allen Renear](https://ischool.illinois.edu/people/allen-renear) and his expertise in within data curation and `Foundations of Data Curation`.
